
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                 
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        MEN'S STYLE STORE CLOTHES.
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div> 
    <!-- para modales, alertas, carruseles etc -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- dezplazamiento del sidebar -->
    <script src="/paneladministrador/recursos/libs/simplebar/simplebar.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons@latest/dist/feather.min.js"></script>

    <!-- App js funcionaiento del sidebar--> 
    <script src="/paneladministrador/recursos/js/app.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/simplebar@latest/dist/simplebar.min.js"></script>
</body>
</html>
